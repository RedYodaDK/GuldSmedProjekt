Gruppemedlemmer: Jacob I & Stig

Fag: Programering
Projekt: Guldsmed

Brug af program:
Åben EXE filen.
Skriv "end" for at stoppe.
Skriv et tal for at finde den bedstepris for den længde.

ADVARSEL!
Skriv ikke inputs over 600 for at undgå lang køretid for den rekursive løgsning. 

SRC:
Indeholder souce koden af programmet.
Dynamisk.cs
Program.cs
Rekrusiv.cs

Report:
Indeholder rappot.pdf



